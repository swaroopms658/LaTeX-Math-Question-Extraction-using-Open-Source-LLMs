from pathlib import Path
from pylatexenc.latex2text import LatexNodes2Text

INPUT_FILE = "F:/rdsharma_extractor/extracted_questions.tex"
OUTPUT_FILE = "F:/rdsharma_extractor/cleaned_questions.tex"

def is_valid_latex(latex_str):
    try:
        LatexNodes2Text().latex_to_text(latex_str)
        return True
    except Exception:
        return False

def strip_prompt_echo(block):
    # Optional: remove prompt text, keep only questions
    if "Questions in LaTeX:" in block:
        return block.split("Questions in LaTeX:", 1)[-1].strip()
    return block

if __name__ == "__main__":
    lines = Path(INPUT_FILE).read_text(encoding="utf-8").splitlines()
    blocks = "\n".join(lines).split("\n\n")
    cleaned, invalid_blocks = [], []

    for block in blocks:
        code = strip_prompt_echo(block.strip())
        if not code:
            continue
        if is_valid_latex(code):
            cleaned.append(code)
        else:
            invalid_blocks.append(code)

    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        for code in cleaned:
            f.write(code + "\n\n")
    print(f"Saved cleaned LaTeX to: {OUTPUT_FILE}")

    if invalid_blocks:
        print(f"\nInvalid LaTeX blocks detected ({len(invalid_blocks)}):")
        for ib in invalid_blocks:
            print("------")
            print(ib)
    else:
        print("No invalid LaTeX blocks found.")
