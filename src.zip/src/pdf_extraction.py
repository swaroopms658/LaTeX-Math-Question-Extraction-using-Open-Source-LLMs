import fitz  # PyMuPDF
import re
import os

def extract_full_text(pdf_path):
    """
    Extract all text from all pages of the PDF, returning a single concatenated string.
    """
    doc = fitz.open(pdf_path)
    full_text = [page.get_text() for page in doc]
    return "\n".join(full_text)

def clean_extracted_text(text):
    """
    Remove common noisy repeated watermark/header/footer lines from extracted text.
    """
    patterns_to_remove = [
        r'Your\s+Flow\s+Find\s+Your\s+for\s+Free\s+eBooks.*',   # Known repetitive phrases
        r'Read\s+Your\s+Flow\s+Find\s+Your\s+for\s+Free\s+eBooks.*',
        r'Buy\s+Now',
        r'Sample\s+Chapter',
        r'Copyright.*',
        r'Download.*',
        r'Dhanpat\s+Rai\s+Publications.*',
        r'DELHI.*',  # Too generic? Use carefully
        # Add more patterns here if needed
    ]
    cleaned_text = text
    for pat in patterns_to_remove:
        cleaned_text = re.sub(pat, '', cleaned_text, flags=re.IGNORECASE)
    # Normalize multiple blank lines to double newline
    cleaned_text = re.sub(r'\n\s*\n\s*\n+', '\n\n', cleaned_text)
    cleaned_text = cleaned_text.strip()
    return cleaned_text

def extract_topic_text(full_text, chapter_num, topic_name):
    """
    Extracts text for a given chapter number and topic from the full PDF text.

    Approach:
    - Splits full text by lines.
    - Detects headers that start with chapter_num.subsection (e.g., '30.3 ').
    - Collects all matching headers (likely TOC and main body both appear).
    - Picks the last matching header (assumed to be main content).
    - Extracts lines between that header and the next found header.
    """
    lines = full_text.splitlines()
    header_lines = []
    header_pattern = re.compile(rf"^{chapter_num}\.\d+\s+", re.IGNORECASE)

    for idx, line in enumerate(lines):
        if header_pattern.match(line.strip()):
            header_lines.append((idx, line.strip()))

    print(f"Found {len(header_lines)} chapter {chapter_num} headers in lines.")
    print("First 20 headers:")
    for idx, (line_num, line_text) in enumerate(header_lines[:20], 1):
        print(f"{idx}. line {line_num}: {line_text}")

    topic_words = topic_name.lower().split()
    target_indices = []
    for i, (line_num, line_text) in enumerate(header_lines):
        line_text_lower = line_text.lower()
        if all(word in line_text_lower for word in topic_words):
            target_indices.append(i)

    if not target_indices:
        raise ValueError(f"Topic '{topic_name}' not found in chapter {chapter_num} headers.")

    # Pick the last occurrence (likely actual content, not TOC)
    target_index = target_indices[-1]

    start_line = header_lines[target_index][0] + 1
    if target_index + 1 < len(header_lines):
        end_line = header_lines[target_index + 1][0]
    else:
        end_line = len(lines)

    topic_lines = lines[start_line:end_line]

    snippet_preview = "\n".join(topic_lines[:10])
    print(f"\nExtracted {len(topic_lines)} lines for topic. Preview:\n{snippet_preview}\n")

    topic_text = "\n".join(topic_lines).strip()
    return topic_text

if __name__ == "__main__":
    # Change this PDF path if your PDF is named differently or at a different location
    pdf_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'rd.pdf'))
    chapter = "30"  # Example chapter number; change as needed
    topic = "Conditional Probability"  # Example topic; use exact phrase from headers printed

    print(f"Loading PDF from: {pdf_path}")
    full_text = extract_full_text(pdf_path)

    print("----- Full text snippet (first 3000 chars) -----")
    print(full_text[:3000])
    print("-------------------------------------------------\n")

    try:
        extracted_topic = extract_topic_text(full_text, chapter, topic)

        # Clean extracted topic text to remove overflowing noise
        cleaned_topic = clean_extracted_text(extracted_topic)

        print(f"\nFinal extracted and cleaned topic text length: {len(cleaned_topic)} characters.\n")
        print("Final extracted topic text snippet (first 1000 chars):\n")
        print(cleaned_topic[:1000])

        # Save extracted cleaned topic text to a file in root directory
        root_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
        save_path = os.path.join(root_dir, 'extracted_topic_text.txt')

        with open(save_path, 'w', encoding='utf-8') as f:
            f.write(cleaned_topic)
        print(f"\nExtracted topic text saved to: {save_path}")

    except Exception as e:
        print("Error during topic extraction:", e)
