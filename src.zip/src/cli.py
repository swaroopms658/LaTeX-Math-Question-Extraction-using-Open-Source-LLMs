import argparse
import os
from pdf_extraction import extract_full_text, extract_topic_text
from chunking import chunk_text
from retrieval import Retriever
from llm_extract import extract_questions
from validate_latex import is_valid_latex

def main():
    parser = argparse.ArgumentParser(description="Extract LaTeX math questions from RD Sharma PDF.")
    parser.add_argument('--chapter', required=True, help="Chapter number e.g. '30'")
    parser.add_argument('--topic', required=True, help="Topic name e.g. 'Conditional Probability'")
    parser.add_argument('--pdf', default=None, help="Path to RD Sharma PDF (default ../data/rd.pdf)")
    parser.add_argument('--output', default="extracted_questions.tex", help="Output LaTeX filename")
    args = parser.parse_args()

    pdf_path = args.pdf or os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'rd.pdf'))
    print(f"Extracting from PDF: {pdf_path}")

    print("Extracting full text...")
    full_text = extract_full_text(pdf_path)

    print(f"Extracting topic text for Chapter {args.chapter}, Topic '{args.topic}'")
    topic_text = extract_topic_text(full_text, args.chapter, args.topic)

    print("Chunking text...")
    chunks = chunk_text(topic_text)

    print(f"Building retriever with {len(chunks)} chunks...")
    retriever = Retriever(chunks)

    query = f"Extract questions for {args.chapter}.{args.topic}"
    print(f"Retrieving top chunks for query: '{query}'")
    relevant_chunks = retriever.retrieve(query, top_k=3)

    all_questions = ""
    for i, chunk in enumerate(relevant_chunks):
        print(f"Processing chunk {i+1} for question extraction...")
        latex_output = extract_questions(chunk)
        if is_valid_latex(latex_output) and latex_output.strip():
            all_questions += latex_output + "\n\n"
        else:
            print(f"Warning: Invalid or empty LaTeX output from chunk {i+1}")

    print(f"Saving extracted questions to {args.output}")
    with open(args.output, 'w', encoding='utf-8') as f:
        f.write(all_questions)

    print("Extraction complete.")

if __name__ == "__main__":
    main()
