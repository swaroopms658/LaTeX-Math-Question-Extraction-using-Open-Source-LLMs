# src/ocr_module.py
import fitz  # PyMuPDF
from PIL import Image
import pytesseract
import io

def ocr_text_from_pdf(pdf_path, dpi=300, lang='eng'):
    """
    Perform OCR on each page of the scanned PDF and return extracted text as a list of page texts.

    Args:
        pdf_path (str): Path to the PDF file.
        dpi (int): Resolution for rendering pages to images for better OCR quality.
        lang (str): Language for Tesseract OCR.

    Returns:
        List[str]: List of extracted texts for each page.
    """
    doc = fitz.open(pdf_path)
    texts = []
    for page_num in range(len(doc)):
        page = doc.load_page(page_num)
        
        # Render page to an image in memory at high dpi for better OCR
        mat = fitz.Matrix(dpi / 72, dpi / 72)  # scale to desired dpi
        pix = page.get_pixmap(matrix=mat, alpha=False)
        
        # Convert pixmap to PIL Image
        img_bytes = pix.tobytes(output="png")
        img = Image.open(io.BytesIO(img_bytes))

        # Run OCR using pytesseract
        text = pytesseract.image_to_string(img, lang=lang)
        texts.append(text)
    return texts

if __name__ == "__main__":
    import os
    sample_pdf = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'data', 'scanned_sample.pdf'))
    print(f"Running OCR on {sample_pdf}")
    pages_text = ocr_text_from_pdf(sample_pdf)
    print(f"Extracted text from {len(pages_text)} pages.")
    print("\nSample OCR text (first page):\n")
    print(pages_text[0][:1000])  # print first 1000 chars from first page
