import re
from pathlib import Path

def chunk_text(text, chunk_size=800):
    """
    Splits text into chunks of approximately `chunk_size` characters, preserving paragraph boundaries.
    """
    paragraphs = re.split(r'\n\s*\n', text)
    chunks = []
    current_chunk = ""

    for para in paragraphs:
        para = para.strip()
        if not para:
            continue
        if len(current_chunk) + len(para) + 2 < chunk_size:
            current_chunk += para + "\n\n"
        else:
            if current_chunk:
                chunks.append(current_chunk.strip())
            current_chunk = para + "\n\n"

    if current_chunk:
        chunks.append(current_chunk.strip())
    return chunks

def is_noisy(chunk):
    """
    Detects if a chunk is noisy or mostly useless based on heuristics.
    """
    noise_patterns = [
        "Buy Now",
        "Sample Chapter",
        "Copyright",
        "Download",
        "eBook",
        # Add more patterns as needed
    ]
    for np in noise_patterns:
        if np.lower() in chunk.lower():
            print(f"Filtering chunk for noise pattern '{np}': starts with '{chunk[:30].replace(chr(10), ' ')}...'")
            return True

    if len(chunk) < 30:
        print(f"Filtering chunk for being too short (length {len(chunk)}): '{chunk[:30].replace(chr(10), ' ')}...'")
        return True

    alnum_count = sum(c.isalnum() for c in chunk)
    alnum_ratio = alnum_count / max(len(chunk), 1)
    if alnum_ratio < 0.4:
        print(f"Filtering chunk for low alnum ratio {alnum_ratio:.2f}: '{chunk[:30].replace(chr(10), ' ')}...'")
        return True

    # Passed all checks: not noisy
    return False

if __name__ == "__main__":
    path_to_file = r"F:\rdsharma_extractor\extracted_topic_text.txt"
    file_path_obj = Path(path_to_file)

    if file_path_obj.exists():
        sample_text = file_path_obj.read_text(encoding="utf-8")
        print(f"Loaded extracted topic text from: {path_to_file}\n")
    else:
        sample_text = "Paste your extracted topic text here if the file does not exist."
        print(f"WARNING: File not found at {path_to_file}. Using demo text instead.\n")

    chunk_size = 800
    chunks = chunk_text(sample_text, chunk_size=chunk_size)

    print(f"Total chunks created before filtering: {len(chunks)}")

    filtered_chunks = []
    for i, c in enumerate(chunks, 1):
        print(f"\nChecking chunk {i} (length {len(c)} characters):")
        print(c[:100].replace('\n', ' ') + "...")
        if not is_noisy(c):
            filtered_chunks.append(c)
        else:
            print(f"Chunk {i} filtered out.")

    print(f"\nChunks after filtering noise: {len(filtered_chunks)}\n")

    for i, chunk in enumerate(filtered_chunks[:5]):
        print(f"--- Chunk {i+1} (length {len(chunk)} chars) ---\n")
        print(chunk[:350])
        if len(chunk) > 350:
            print("...")
        print()
    output_path = r"F:\rdsharma_extractor\filtered_chunks.txt"
    with open(output_path, "w", encoding="utf-8") as f:
        for chunk in filtered_chunks:
            f.write(chunk)
            f.write("\n\n")  # Double newline as separator

    print(f"Filtered chunks saved to {output_path}")