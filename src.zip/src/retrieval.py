from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

def normalize_embeddings(embeddings):
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    return embeddings / (norms + 1e-10)  # avoid divide by zero

class Retriever:
    def __init__(self, chunks):
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.chunks = chunks
        print("Encoding chunks...")
        embeddings = self.model.encode(chunks, convert_to_numpy=True)
        self.embeddings = normalize_embeddings(embeddings)
        dim = self.embeddings.shape[1]
        self.index = faiss.IndexFlatIP(dim)  # inner product = cosine similarity
        self.index.add(self.embeddings)
        print(f"Indexed {self.index.ntotal} chunks with embedding dim {dim}")

    def retrieve(self, query, top_k=5):
        query_emb = self.model.encode([query], convert_to_numpy=True)
        query_emb = normalize_embeddings(query_emb)
        distances, indices = self.index.search(query_emb, top_k)
        results = []
        for idx in indices[0]:
            if idx < len(self.chunks):
                results.append(self.chunks[idx])
        print(f"Retrieved {len(results)} chunks.")
        return results


if __name__ == "__main__":
    chunks = ["Sample chunk text 1", "Sample chunk text 2", "Sample chunk text 3"]
    retriever = Retriever(chunks)
    query = "Extract questions for 30.3 Conditional Probability"
    results = retriever.retrieve(query, top_k=3)
    for i, res in enumerate(results):
        print(f"Result {i+1}:\n{res}\n")
