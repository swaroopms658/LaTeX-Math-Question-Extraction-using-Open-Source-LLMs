from pathlib import Path
from llm_extract import extract_questions

chunks_file = Path("F:/rdsharma_extractor/filtered_chunks.txt")

if not chunks_file.exists():
    raise FileNotFoundError(f"{chunks_file} not found! Run chunking.py first and save chunks.")

# Read chunks separated by double newlines
raw_text = chunks_file.read_text(encoding="utf-8")
chunks = [c.strip() for c in raw_text.split('\n\n') if c.strip()]

all_questions = []
for idx, chunk in enumerate(chunks, 1):
    print(f"Processing chunk {idx}/{len(chunks)}...")
    latex = extract_questions(chunk)
    all_questions.append(latex)

# Save all extracted questions into one LaTeX file
output_file = Path("F:/rdsharma_extractor/extracted_questions.tex")
with output_file.open("w", encoding="utf-8") as f:
    for q in all_questions:
        f.write(q + "\n\n")

print(f"Extraction complete. Saved all questions to {output_file}")
