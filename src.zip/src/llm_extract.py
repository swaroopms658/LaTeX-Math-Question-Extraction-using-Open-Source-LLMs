from transformers import pipeline

# Use a free, instruction-tuned GPT-like model from HuggingFace hub
# Example: microsoft/phi-3-mini-4k-instruct (replace with preferred one if you want)
MODEL_NAME = "microsoft/phi-3-mini-4k-instruct"

# Create the text-generation pipeline
extractor = pipeline(
    "text-generation",
    model=MODEL_NAME,
    max_new_tokens=512,
    temperature=1e-5,  # Fix: must be >0
    device=0,  # or -1 for CPU
)


def extract_questions(text_chunk):
    prompt = (
        "Extract only the math questions from the following text.\n"
        "Output the questions strictly in LaTeX math notation format.\n"
        "Do NOT add any explanations or other text.\n\n"
        f"Text:\n{text_chunk}\n\n"
        "Questions in LaTeX:"
    )
    output = extractor(prompt)[0]['generated_text']

    # Optional: Remove prompt echo if model outputs prompt as well
    # You can implement prompt trimming here if needed

    return output.strip()


if __name__ == "__main__":
    sample_text = "Example math textbook text with questions and explanations..."
    latex_questions = extract_questions(sample_text)
    print("Extracted LaTeX questions:\n", latex_questions)
