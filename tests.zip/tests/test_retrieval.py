import pytest
from src.retrieval import Retriever

def test_retriever_basic_functionality():
    chunks = [
        "This chunk talks about conditional probability theorems.",
        "Discussion on algebra and geometry here.",
        "Theory of independent events explained."
    ]

    retriever = Retriever(chunks)
    results = retriever.retrieve("conditional probability", top_k=2)

    assert isinstance(results, list)
    assert len(results) == 2
    # At least one retrieved chunk should contain the query phrase
    assert any("conditional probability" in r.lower() for r in results)
