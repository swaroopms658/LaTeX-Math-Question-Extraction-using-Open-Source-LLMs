import pytest
from unittest.mock import patch
import src.llm_extract as llm_extract

def test_extract_questions_prompt_building():
    sample_chunk = "Find the roots of quadratic equation."
    prompt = (
        "Extract only the math questions from the following text.\n"
        "Output the questions strictly in LaTeX math notation format.\n"
        "Do NOT add any explanations or other text.\n\n"
        f"Text:\n{sample_chunk}\n\n"
        "Questions in LaTeX:"
    )
    # You can test prompt explicitly or skip if private to function

@patch('src.llm_extract.extractor')
def test_extract_questions_mocked(mock_extractor):
    mock_extractor.return_value = [{"generated_text": "Questions in LaTeX:\n\\(x=1\\)"}]

    output = llm_extract.extract_questions("Solve for x")
    assert "\\(x=1\\)" in output
