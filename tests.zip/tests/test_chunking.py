import pytest
from src.chunking import chunk_text, is_noisy

sample_text = (
    "Paragraph one with some math text.\n\n"
    "Paragraph two with more content that will create multiple chunks.\n\n"
    "Buy Now special offer spam chunk to be filtered."
)

def test_chunk_text():
    chunks = chunk_text(sample_text, chunk_size=50)
    assert isinstance(chunks, list)
    assert len(chunks) > 1
    assert all(isinstance(c, str) for c in chunks)

def test_is_noisy_positive_and_negative():
    noisy_chunk = "Buy Now this chunk should be detected as noisy."
    clean_chunk = "This chunk contains clean mathematical content."

    assert is_noisy(noisy_chunk) is True
    assert is_noisy(clean_chunk) is False

def test_chunk_and_filter():
    chunks = chunk_text(sample_text, chunk_size=100)
    filtered = [c for c in chunks if not is_noisy(c)]
    # The spam chunk should be filtered out
    assert all("Buy Now" not in c for c in filtered)
